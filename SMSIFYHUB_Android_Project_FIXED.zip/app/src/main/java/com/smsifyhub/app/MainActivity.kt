package com.smsifyhub.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.smsifyhub.app.service.FloatingWindowService
import com.smsifyhub.app.ui.ConsoleScreen
import com.smsifyhub.app.ui.DashboardScreen
import com.smsifyhub.app.ui.SmsifyViewModel
import com.smsifyhub.app.ui.SplashScreen
import com.smsifyhub.app.ui.theme.SMSIFYHUBTheme

class MainActivity : ComponentActivity() {

    private val viewModel: SmsifyViewModel by viewModels()

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            Toast.makeText(this, "Notifications disabled. You won't hear OTP alerts in background.", Toast.LENGTH_SHORT).show()
        }
    }

    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (Settings.canDrawOverlays(this)) {
            startFloatingWindowService()
            viewModel.setFloatingPopupEnabled(true)
        } else {
            viewModel.setFloatingPopupEnabled(false)
            Toast.makeText(this, "Overlay permission is required for Floating Popup window", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Request notification permission on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            SMSIFYHUBTheme {
                var currentScreen by remember { mutableStateOf("splash") }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF070913))
                ) {
                    Crossfade(targetState = currentScreen, label = "screen_transition") { screen ->
                        when (screen) {
                            "splash" -> SplashScreen(onSplashFinished = { currentScreen = "dashboard" })
                            "dashboard" -> DashboardScreen(
                                viewModel = viewModel,
                                onOpenConsole = { currentScreen = "console" },
                                onToggleFloatingPopup = { enable ->
                                    handleToggleFloatingPopup(enable)
                                }
                            )
                            "console" -> ConsoleScreen(
                                viewModel = viewModel,
                                onBack = { currentScreen = "dashboard" }
                            )
                        }
                    }
                }
            }
        }
    }

    private fun handleToggleFloatingPopup(enable: Boolean) {
        if (enable) {
            if (Settings.canDrawOverlays(this)) {
                startFloatingWindowService()
                viewModel.setFloatingPopupEnabled(true)
            } else {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                overlayPermissionLauncher.launch(intent)
            }
        } else {
            stopFloatingWindowService()
            viewModel.setFloatingPopupEnabled(false)
        }
    }

    private fun startFloatingWindowService() {
        val intent = Intent(this, FloatingWindowService::class.java).apply {
            action = FloatingWindowService.ACTION_SHOW
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopFloatingWindowService() {
        val intent = Intent(this, FloatingWindowService::class.java).apply {
            action = FloatingWindowService.ACTION_STOP
        }
        startService(intent)
    }
}
