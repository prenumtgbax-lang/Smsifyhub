package com.smsifyhub.app.data

import com.google.gson.annotations.SerializedName
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// 1. Get Number Response DTO
data class GetNumberResponseDto(
    @SerializedName("success") val success: Boolean,
    @SerializedName("session_id") val sessionId: Long? = null,
    @SerializedName("number") val number: String? = null,
    @SerializedName("phone_number") val phoneNumber: String? = null,
    @SerializedName("number_with_plus") val numberWithPlus: String? = null,
    @SerializedName("provider") val provider: String? = null,
    @SerializedName("requested_range") val requestedRange: String? = null,
    @SerializedName("service") val service: String? = null,
    @SerializedName("status") val status: String? = null,
    @SerializedName("expires_in") val expiresIn: Int? = null,
    @SerializedName("message") val message: String? = null
)

// 2. Get OTP Response DTO
data class GetOtpResponseDto(
    @SerializedName("success") val success: Boolean,
    @SerializedName("received") val received: Boolean? = false,
    @SerializedName("status") val status: String? = null,
    @SerializedName("session_id") val sessionId: Long? = null,
    @SerializedName("otp") val otp: String? = null,
    @SerializedName("code") val code: String? = null,
    @SerializedName("sms") val sms: String? = null,
    @SerializedName("message") val message: String? = null,
    @SerializedName("sender") val sender: String? = null
)

// 3. Console Feed Response DTO
data class ConsoleTrafficItemDto(
    @SerializedName("time") val time: String? = null,
    @SerializedName("operator") val operator: String? = null,
    @SerializedName("country") val country: String? = null,
    @SerializedName("flag") val flag: String? = null,
    @SerializedName("app") val app: String? = null,
    @SerializedName("number") val number: String? = null,
    @SerializedName("range") val range: String? = null,
    @SerializedName("sms") val sms: String? = null,
    @SerializedName("timestamp") val timestamp: Long? = null
)

data class ConsoleFeedResponseDto(
    @SerializedName("success") val success: Boolean,
    @SerializedName("total_hits") val totalHits: Int? = null,
    @SerializedName("active_ranges") val activeRanges: List<String>? = null,
    @SerializedName("messages") val messages: List<ConsoleTrafficItemDto>? = null,
    @SerializedName("message") val message: String? = null
)

interface ApiService {

    @GET("get-number.php")
    suspend fun getNumber(
        @Query("api_key") apiKey: String,
        @Query("range") range: String,
        @Query("service") service: String? = null
    ): Response<GetNumberResponseDto>

    @GET("get-otp.php")
    suspend fun getOtp(
        @Query("api_key") apiKey: String,
        @Query("session_id") sessionId: String
    ): Response<GetOtpResponseDto>

    @GET("console-feed.php")
    suspend fun getConsoleFeed(
        @Query("api_key") apiKey: String
    ): Response<ConsoleFeedResponseDto>

    companion object {
        private const val BASE_URL = "https://panel.smsifyhub.site/api/"

        fun create(): ApiService {
            val logging = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BASIC
            }

            val client = OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .addInterceptor(logging)
                .build()

            return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(ApiService::class.java)
        }
    }
}
