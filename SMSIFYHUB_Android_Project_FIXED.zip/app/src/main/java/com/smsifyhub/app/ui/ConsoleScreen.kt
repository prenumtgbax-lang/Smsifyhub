package com.smsifyhub.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConsoleScreen(
    viewModel: SmsifyViewModel,
    onBack: () -> Unit
) {
    val consoleState by viewModel.consoleState.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val cyanGlow = Color(0xFF00E5FF)

    // Auto-refresh every 2 seconds
    LaunchedEffect(Unit) {
        while (true) {
            viewModel.loadConsoleFeed()
            delay(2000)
        }
    }

    fun copyResponse(text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Console Feed", text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "API response copied to clipboard!", Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070913))
            .padding(16.dp)
    ) {
        // Top Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = cyanGlow)
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "LIVE CONSOLE",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    color = Color.White,
                    letterSpacing = 2.sp
                )
            }

            IconButton(onClick = { viewModel.loadConsoleFeed() }) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = "Refresh", tint = cyanGlow)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Stats Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1428))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("LATENCY", fontSize = 10.sp, color = Color.Gray)
                    Text("${consoleState.responseTimeMs} ms", fontWeight = FontWeight.Bold, color = cyanGlow)
                }
            }

            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1428))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("TOTAL HITS", fontSize = 10.sp, color = Color.Gray)
                    Text("${consoleState.totalHits}", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1428))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("RANGES", fontSize = 10.sp, color = Color.Gray)
                    Text("${consoleState.activeRanges.size}", fontWeight = FontWeight.Bold, color = Color(0xFFB026FF))
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Actions
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { copyResponse(consoleState.rawJson) },
                enabled = consoleState.rawJson.isNotBlank(),
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0091EA))
            ) {
                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("COPY RESPONSE")
            }

            OutlinedButton(
                onClick = onBack,
                modifier = Modifier.weight(0.7f)
            ) {
                Text("BACK")
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // JSON View
        Box(
            modifier = Modifier
                .fillMaxSize()
                .border(1.dp, Color(0x3300E5FF), RoundedCornerShape(12.dp))
                .background(Color(0xFF04060E))
                .padding(12.dp)
                .verticalScroll(rememberScrollState())
        ) {
            if (consoleState.isLoading) {
                CircularProgressIndicator(
                    color = cyanGlow,
                    modifier = Modifier.align(Alignment.Center)
                )
            } else if (consoleState.errorMessage.isNotBlank()) {
                Text(
                    text = "Error: " + consoleState.errorMessage,
                    color = Color.Red,
                    modifier = Modifier.align(Alignment.Center)
                )
            } else {
                Text(
                    text = if (consoleState.rawJson.isNotBlank()) consoleState.rawJson else "No console response loaded. Tap Refresh.",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = Color(0xFF67E8F9)
                )
            }
        }
    }
}
