package com.smsifyhub.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: SmsifyViewModel,
    onOpenConsole: () -> Unit,
    onToggleFloatingPopup: (Boolean) -> Unit
) {
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val floatingEnabled by viewModel.floatingPopupEnabled.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var inputTargetRange by remember { mutableStateOf("23278XXX") }

    val cyanGlow = Color(0xFF00E5FF)
    val purpleGlow = Color(0xFFB026FF)
    val orangeGlow = Color(0xFFFF6D00)
    val darkCardBg = Color(0xDE0E1428)

    fun copyText(label: String, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText(label, text)
        clipboard.setPrimaryClip(clip)
        Toast.makeText(context, "$label copied!", Toast.LENGTH_SHORT).show()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070913))
            .verticalScroll(rememberScrollState())
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // A. SMSIFYHUB TITLE AT THE TOP
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(cyanGlow)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "SMSIFYHUB",
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 3.sp,
                color = Color.White
            )
        }
        Text(
            text = "NEXT-GEN SMS OTP RECEPTOR",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = cyanGlow,
            letterSpacing = 2.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // B. FLOATING POPUP ON/OFF TOGGLE
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = darkCardBg),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, if (floatingEnabled) cyanGlow else Color(0x3300E5FF), RoundedCornerShape(16.dp))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PictureInPicture,
                        contentDescription = "Floating Overlay",
                        tint = if (floatingEnabled) cyanGlow else Color.Gray,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "FLOATING POPUP WINDOW",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = if (floatingEnabled) "Mini-window Active over other apps" else "Disabled (Tap switch to enable)",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }

                Switch(
                    checked = floatingEnabled,
                    onCheckedChange = { onToggleFloatingPopup(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = cyanGlow,
                        uncheckedTrackColor = Color(0xFF1E293B)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // C. GET NUMBER SECTION
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = darkCardBg),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color(0x33B026FF), RoundedCornerShape(16.dp))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "GET NUMBER SECTION",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = purpleGlow,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = inputTargetRange,
                    onValueChange = { inputTargetRange = it },
                    label = { Text("Target Range", color = Color.Gray) },
                    placeholder = { Text("e.g. 23278XXX", color = Color.DarkGray) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = cyanGlow,
                        unfocusedBorderColor = Color(0x4400E5FF)
                    )
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { viewModel.requestNumber(inputTargetRange) },
                    enabled = !sessionState.isLoading,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B0FF))
                ) {
                    if (sessionState.isLoading) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("GENERATING NUMBER...")
                    } else {
                        Icon(imageVector = Icons.Default.PhoneIphone, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("GET NUMBER", fontWeight = FontWeight.Bold)
                    }
                }

                if (sessionState.phoneNumber.isNotBlank()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color(0xFF081024))
                            .border(1.dp, cyanGlow, RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "GENERATED NUMBER",
                                    fontSize = 11.sp,
                                    color = Color.Gray
                                )
                                Text(
                                    text = "SESSION: #${sessionState.sessionId}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = cyanGlow
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = sessionState.phoneNumber,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = Color.White,
                                fontFamily = FontFamily.Monospace
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedButton(
                                onClick = { copyText("Phone Number", sessionState.phoneNumber) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("COPY NUMBER")
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // D. OTP RECEIVING SECTION
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = darkCardBg),
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    1.dp,
                    if (sessionState.status == "received") orangeGlow else Color(0x33FF6D00),
                    RoundedCornerShape(16.dp)
                )
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "OTP RECEIVING SECTION",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = orangeGlow,
                        letterSpacing = 1.sp
                    )

                    if (sessionState.status == "waiting") {
                        Text(
                            text = "${sessionState.elapsedSeconds}s",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = cyanGlow
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                when (sessionState.status) {
                    "waiting" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF140D26))
                                .border(1.dp, purpleGlow, RoundedCornerShape(12.dp))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                CircularProgressIndicator(color = purpleGlow, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(10.dp))
                                Text("Waiting for OTP...", fontWeight = FontWeight.Bold, color = Color.White)
                                Text("Polling active session every 3 seconds", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                    "received" -> {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF241400))
                                .border(1.dp, orangeGlow, RoundedCornerShape(12.dp))
                                .padding(16.dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("OTP RECEIVED", color = orangeGlow, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = sessionState.otp,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Black,
                                    letterSpacing = 4.sp,
                                    color = Color.White,
                                    fontFamily = FontFamily.Monospace
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = { copyText("OTP Code", sessionState.otp) },
                                    colors = ButtonDefaults.buttonColors(containerColor = orangeGlow),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("COPY OTP", fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    else -> {
                        Text(
                            text = if (sessionState.phoneNumber.isBlank()) "Generate a number above to begin waiting for OTP" else "Session Idle",
                            fontSize = 12.sp,
                            color = Color.Gray
                        )
                    }
                }

                if (sessionState.smsText.isNotBlank()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Message: " + sessionState.smsText, fontSize = 12.sp, color = Color.LightGray)
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = { copyText("SMS Message", sessionState.smsText) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("COPY MESSAGE")
                    }
                }

                if (sessionState.status == "waiting") {
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = { viewModel.refreshOtpManual() },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("REFRESH")
                        }
                        Button(
                            onClick = { viewModel.stopWaiting() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("STOP WAITING")
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // E. LIVE CONSOLE BUTTON
        Button(
            onClick = {
                viewModel.loadConsoleFeed()
                onOpenConsole()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
            border = androidx.compose.foundation.BorderStroke(1.dp, cyanGlow)
        ) {
            Icon(imageVector = Icons.Default.Terminal, contentDescription = null, tint = cyanGlow)
            Spacer(modifier = Modifier.width(8.dp))
            Text("LIVE CONSOLE", fontWeight = FontWeight.Bold, color = cyanGlow, letterSpacing = 1.sp)
        }

        Spacer(modifier = Modifier.height(28.dp))

        // DEVELOPER INFO AT THE BOTTOM
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "Developer: PARANTO",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.LightGray
            )
            Text(
                text = "Email: parantobaby@gmail.com",
                fontSize = 12.sp,
                color = Color.Gray
            )
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}
