package com.smsifyhub.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun FloatingPopupView(
    onCopyNumber: (String) -> Unit,
    onCopyOtp: (String) -> Unit,
    onOpenDashboard: () -> Unit,
    onHide: () -> Unit,
    onClose: () -> Unit
) {
    val number by FloatingSessionState.numberFlow.collectAsStateWithLifecycle()
    val otp by FloatingSessionState.otpFlow.collectAsStateWithLifecycle()
    val status by FloatingSessionState.statusFlow.collectAsStateWithLifecycle()

    val cyanGlow = Color(0xFF00E5FF)
    val orangeGlow = Color(0xFFFF9100)
    val darkBg = Color(0xF5070B1A)

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = darkBg),
        modifier = Modifier
            .width(250.dp)
            .border(1.5.dp, if (otp.isNotBlank()) orangeGlow else cyanGlow, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Header with Range System at top
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "SMSIFYHUB",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp,
                        color = cyanGlow
                    )
                }
                IconButton(onClick = onClose, modifier = Modifier.size(22.dp)) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
                }
            }

            // Range System Banner at Top
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .background(Color(0x1A00E5FF), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "RANGE: 23278XXX", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = cyanGlow)
                Text(text = "2s Auto", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFF10B981))
            }

            Divider(color = Color(0x3300E5FF), modifier = Modifier.padding(vertical = 4.dp))

            // 2. Number Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(text = "PHONE NUMBER:", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text(
                        text = if (number.isNotBlank()) number else "Waiting for number...",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Button(
                    onClick = { onCopyNumber(number) },
                    enabled = number.isNotBlank(),
                    modifier = Modifier.height(28.dp),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                ) {
                    Text("COPY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 3. OTP Row (High Visibility Glow)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(if (otp.isNotBlank()) Color(0x2BFF6D00) else Color(0x1400E5FF), RoundedCornerShape(10.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (otp.isNotBlank()) "RECEIVED OTP:" else "STATUS: ${status.take(15)}",
                        fontSize = 9.sp,
                        color = if (otp.isNotBlank()) orangeGlow else Color.LightGray,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (otp.isNotBlank()) otp else "••••••",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp,
                        color = if (otp.isNotBlank()) orangeGlow else Color.White,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Button(
                    onClick = { onCopyOtp(otp) },
                    enabled = otp.isNotBlank(),
                    modifier = Modifier.height(28.dp),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C))
                ) {
                    Text("COPY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 4. Color-coded Bottom Buttons (Hide, Dashboard, Close - No Edit button)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Button(
                    onClick = onHide,
                    modifier = Modifier.weight(1f).height(30.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("HIDE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }

                Button(
                    onClick = onOpenDashboard,
                    modifier = Modifier.weight(1.1f).height(30.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("DASHBOARD", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }

                Button(
                    onClick = onClose,
                    modifier = Modifier.weight(0.9f).height(30.dp),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151)),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text("CLOSE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }
    }
}
