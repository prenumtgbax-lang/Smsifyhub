package com.smsifyhub.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val SmsifyDarkColorScheme = darkColorScheme(
    primary = Color(0xFF00E5FF),
    onPrimary = Color(0xFF001F24),
    secondary = Color(0xFFFF9100),
    onSecondary = Color(0xFF241300),
    background = Color(0xFF070913),
    onBackground = Color(0xFFFFFFFF),
    surface = Color(0xFF0E1428),
    onSurface = Color(0xFFFFFFFF),
    error = Color(0xFFFF5252)
)

@Composable
fun SMSIFYHUBTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = SmsifyDarkColorScheme,
        content = content
    )
}
