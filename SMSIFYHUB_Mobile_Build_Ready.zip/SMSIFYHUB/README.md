# SMSIFYHUB - Android Application (Kotlin & Jetpack Compose)

Developer: PARANTO
Email: parantobaby@gmail.com

## How to Open and Run in Android Studio:

1. Open Android Studio.
2. Select **File > Open...** and select this unzipped folder (`SMSIFYHUB`).
3. Android Studio will automatically sync the Gradle files (`settings.gradle.kts` and `build.gradle.kts`).
4. Connect an Android phone (via USB debugging) or start an Android Emulator.
5. Click the green **Run (▶)** button or choose **Build > Build Bundle(s) / APK(s) > Build APK(s)** to generate `app-debug.apk`.
6. Transfer the generated APK to your Android device and install!

### Features:
- Autonomous OTP receptor with real-time polling
- Draggable Floating Popup Window (SYSTEM_ALERT_WINDOW)
- In-popup Range selector & Get Number action
- High priority sound notifications
- Live Console feed\n