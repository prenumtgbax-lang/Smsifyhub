package com.smsifyhub.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle

@Composable
fun FloatingPopupView(
    onGenerateNumber: (String) -> Unit,
    onCopyNumber: (String) -> Unit,
    onCopyOtp: (String) -> Unit,
    onOpenDashboard: () -> Unit,
    onCloseToIcon: () -> Unit,
    onExpandFromIcon: () -> Unit,
    onDismissService: () -> Unit
) {
    val number by FloatingSessionState.numberFlow.collectAsStateWithLifecycle()
    val otp by FloatingSessionState.otpFlow.collectAsStateWithLifecycle()
    val status by FloatingSessionState.statusFlow.collectAsStateWithLifecycle()
    val isMinimized by FloatingSessionState.isMinimizedFlow.collectAsStateWithLifecycle()

    var inputPopupRange by remember { mutableStateOf("23278XXX") }
    var isGenerating by remember { mutableStateOf(false) }

    val cyanGlow = Color(0xFF00E5FF)
    val orangeGlow = Color(0xFFFF9100)
    val darkBg = Color(0xF5070B1A)

    if (isMinimized) {
        // --- 1. MINIMIZED FLOATING ICON (Movable / Draggable) ---
        Box(
            modifier = Modifier
                .size(58.dp)
                .clip(CircleShape)
                .background(darkBg)
                .border(2.dp, if (otp.isNotBlank()) orangeGlow else cyanGlow, CircleShape)
                .clickable { onExpandFromIcon() },
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Mail,
                    contentDescription = "SMSIFYHUB",
                    tint = if (otp.isNotBlank()) orangeGlow else cyanGlow,
                    modifier = Modifier.size(24.dp)
                )
                Text(
                    text = if (otp.isNotBlank()) "OTP!" else "HUB",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Black,
                    color = if (otp.isNotBlank()) orangeGlow else Color.White
                )
            }

            // Notification indicator badge when OTP is ready
            if (otp.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .align(Alignment.TopEnd)
                        .clip(CircleShape)
                        .background(Color(0xFFFF3D00))
                        .border(1.5.dp, Color.White, CircleShape)
                )
            }
        }
    } else {
        // --- 2. EXPANDED POPUP (With Get Number inside popup, HIDE removed, Close -> Icon) ---
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = darkBg),
            modifier = Modifier
                .width(270.dp)
                .border(1.5.dp, if (otp.isNotBlank()) orangeGlow else cyanGlow, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header: Title + Close (which turns into floating icon)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "SMSIFYHUB",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = cyanGlow
                        )
                    }

                    IconButton(
                        onClick = onCloseToIcon,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Minimize to Floating Icon",
                            tint = Color(0xFF94A3B8),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // IN-POPUP GET NUMBER SYSTEM (User requested: "popp মধ্যে আমার নাম্বারে উপরে গেট নাম্বার সিস্টেম সহ থাকিবে")
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0x1400E5FF), RoundedCornerShape(8.dp))
                        .padding(4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    OutlinedTextField(
                        value = inputPopupRange,
                        onValueChange = { inputPopupRange = it },
                        singleLine = true,
                        placeholder = { Text("Range...", fontSize = 9.sp, color = Color.Gray) },
                        modifier = Modifier
                            .weight(1f)
                            .height(34.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedBorderColor = cyanGlow,
                            unfocusedBorderColor = Color(0x4400E5FF)
                        )
                    )

                    Button(
                        onClick = {
                            isGenerating = true
                            onGenerateNumber(inputPopupRange)
                        },
                        modifier = Modifier.height(34.dp),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B0FF))
                    ) {
                        Text("GET", fontSize = 9.sp, fontWeight = FontWeight.Black)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Phone Number Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "PHONE NUMBER:", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        Text(
                            text = if (number.isNotBlank()) number else "Waiting for number...",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Button(
                        onClick = { onCopyNumber(number) },
                        enabled = number.isNotBlank(),
                        modifier = Modifier.height(28.dp),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
                    ) {
                        Text("COPY", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // OTP Row (Glows neon orange instantly when received)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(if (otp.isNotBlank()) Color(0x2BFF6D00) else Color(0x1400E5FF), RoundedCornerShape(10.dp))
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (otp.isNotBlank()) "⚡ RECEIVED OTP:" else "STATUS: ${status.take(15)}",
                            fontSize = 9.sp,
                            color = if (otp.isNotBlank()) orangeGlow else Color.LightGray,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (otp.isNotBlank()) otp else "••••••",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 2.sp,
                            color = if (otp.isNotBlank()) orangeGlow else Color.White,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Button(
                        onClick = { onCopyOtp(otp) },
                        enabled = otp.isNotBlank(),
                        modifier = Modifier.height(28.dp),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C))
                    ) {
                        Text("COPY", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Bottom Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Button(
                        onClick = onOpenDashboard,
                        modifier = Modifier.weight(1.2f).height(30.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("DASHBOARD", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    Button(
                        onClick = onCloseToIcon,
                        modifier = Modifier.weight(1f).height(30.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF334155)),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("CLOSE", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}

