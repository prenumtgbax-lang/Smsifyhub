package com.smsifyhub.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.smsifyhub.app.data.ApiService
import com.smsifyhub.app.data.ConsoleFeedResponseDto
import com.smsifyhub.app.data.GetNumberResponseDto
import com.smsifyhub.app.data.GetOtpResponseDto
import com.smsifyhub.app.util.NotificationHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ActiveSessionUiState(
    val sessionId: String = "",
    val phoneNumber: String = "",
    val range: String = "23278XXX",
    val status: String = "idle", // idle, waiting, received, stopped, error
    val otp: String = "",
    val smsText: String = "",
    val elapsedSeconds: Int = 0,
    val isLoading: Boolean = false,
    val errorMessage: String = ""
)

data class ConsoleUiState(
    val isLoading: Boolean = false,
    val rawJson: String = "",
    val responseTimeMs: Long = 0,
    val totalHits: Int = 0,
    val activeRanges: List<String> = emptyList(),
    val messagesCount: Int = 0,
    val errorMessage: String = ""
)

object FloatingSessionState {
    val numberFlow = MutableStateFlow("")
    val otpFlow = MutableStateFlow("")
    val statusFlow = MutableStateFlow("Idle")
    val isVisibleFlow = MutableStateFlow(false)
    val isMinimizedFlow = MutableStateFlow(false) // true = floating icon, false = full popup
}

class SmsifyViewModel(application: Application) : AndroidViewModel(application) {

    private val api = ApiService.create()
    private val notificationHelper = NotificationHelper(application)
    private val apiKey = "smsify_7ee5a9cfa1a113e6d7b799ea"

    private val _sessionState = MutableStateFlow(ActiveSessionUiState())
    val sessionState: StateFlow<ActiveSessionUiState> = _sessionState.asStateFlow()

    private val _consoleState = MutableStateFlow(ConsoleUiState())
    val consoleState: StateFlow<ConsoleUiState> = _consoleState.asStateFlow()

    private val _floatingPopupEnabled = MutableStateFlow(false)
    val floatingPopupEnabled: StateFlow<Boolean> = _floatingPopupEnabled.asStateFlow()

    private var pollingJob: Job? = null
    private var timerJob: Job? = null

    fun setFloatingPopupEnabled(enabled: Boolean) {
        _floatingPopupEnabled.value = enabled
        FloatingSessionState.isVisibleFlow.value = enabled
    }

    fun requestNumber(range: String) {
        if (range.isBlank()) {
            _sessionState.update { it.copy(errorMessage = "Please enter a valid range (e.g. 23278XXX)") }
            return
        }

        stopWaiting()
        _sessionState.update {
            it.copy(
                isLoading = true,
                range = range,
                errorMessage = "",
                status = "requesting"
            )
        }

        viewModelScope.launch {
            try {
                val response = api.getNumber(apiKey = apiKey, range = range)
                if (response.isSuccessful && response.body()?.success == true) {
                    val body = response.body()!!
                    val num = body.phoneNumber ?: body.number ?: ""
                    val sid = body.sessionId?.toString() ?: ""

                    _sessionState.update {
                        it.copy(
                            isLoading = false,
                            phoneNumber = num,
                            sessionId = sid,
                            status = "waiting",
                            otp = "",
                            smsText = "",
                            elapsedSeconds = 0,
                            errorMessage = ""
                        )
                    }

                    FloatingSessionState.numberFlow.value = num
                    FloatingSessionState.otpFlow.value = ""
                    FloatingSessionState.statusFlow.value = "Waiting for OTP..."

                    startOtpPolling(sid)
                } else {
                    val errMsg = response.body()?.message ?: "Failed to generate number for range $range"
                    _sessionState.update { it.copy(isLoading = false, errorMessage = errMsg, status = "error") }
                }
            } catch (e: Exception) {
                _sessionState.update { it.copy(isLoading = false, errorMessage = e.message ?: "Network error", status = "error") }
            }
        }
    }

    private fun startOtpPolling(sessionId: String) {
        pollingJob?.cancel()
        timerJob?.cancel()

        // Elapsed time counter
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _sessionState.update { it.copy(elapsedSeconds = it.elapsedSeconds + 1) }
            }
        }

        // Dedicated single polling job - checks immediately then polls every 1.2s for instant delivery
        pollingJob = viewModelScope.launch {
            var attempts = 0
            val maxAttempts = 180 // ~3.5 minutes of instant live polling

            while (attempts < maxAttempts) {
                try {
                    val res = api.getOtp(apiKey = apiKey, sessionId = sessionId)
                    if (res.isSuccessful && res.body()?.success == true) {
                        val body = res.body()!!

                        if (body.received == true || !body.otp.isNullOrBlank() || !body.code.isNullOrBlank()) {
                            val receivedOtp = body.otp ?: body.code ?: extractOtp(body.sms ?: body.message ?: "")
                            val fullSms = body.sms ?: body.message ?: "OTP received for verification"

                            _sessionState.update {
                                it.copy(
                                    status = "received",
                                    otp = receivedOtp,
                                    smsText = fullSms
                                )
                            }

                            FloatingSessionState.otpFlow.value = receivedOtp
                            FloatingSessionState.statusFlow.value = "OTP Received!"

                            notificationHelper.showOtpNotification(
                                number = _sessionState.value.phoneNumber,
                                otp = receivedOtp
                            )
                            stopWaiting()
                            break
                        }
                    }
                } catch (e: Exception) {
                    // Safe retry without crashing
                }
                delay(1200)
                attempts++
            }
        }
    }

    fun stopWaiting() {
        pollingJob?.cancel()
        timerJob?.cancel()
        pollingJob = null
        timerJob = null
        if (_sessionState.value.status == "waiting") {
            _sessionState.update { it.copy(status = "stopped") }
            FloatingSessionState.statusFlow.value = "Stopped"
        }
    }

    fun refreshOtpManual() {
        val sid = _sessionState.value.sessionId
        if (sid.isBlank()) return

        viewModelScope.launch {
            try {
                val res = api.getOtp(apiKey = apiKey, sessionId = sid)
                if (res.isSuccessful && res.body()?.received == true) {
                    val body = res.body()!!
                    val receivedOtp = body.otp ?: body.code ?: extractOtp(body.sms ?: "")
                    _sessionState.update {
                        it.copy(
                            status = "received",
                            otp = receivedOtp,
                            smsText = body.sms ?: ""
                        )
                    }
                    FloatingSessionState.otpFlow.value = receivedOtp
                    FloatingSessionState.statusFlow.value = "OTP Received!"
                }
            } catch (e: Exception) {
                // Ignore transient manual check error
            }
        }
    }

    fun loadConsoleFeed() {
        _consoleState.update { it.copy(isLoading = true, errorMessage = "") }
        val startTime = System.currentTimeMillis()

        viewModelScope.launch {
            try {
                val response = api.getConsoleFeed(apiKey = apiKey)
                val duration = System.currentTimeMillis() - startTime

                if (response.isSuccessful && response.body()?.success == true) {
                    val body = response.body()!!
                    _consoleState.update {
                        it.copy(
                            isLoading = false,
                            rawJson = com.google.gson.GsonBuilder().setPrettyPrinting().create().toJson(body),
                            responseTimeMs = duration,
                            totalHits = body.totalHits ?: 0,
                            activeRanges = body.activeRanges ?: emptyList(),
                            messagesCount = body.messages?.size ?: 0
                        )
                    }
                } else {
                    _consoleState.update {
                        it.copy(
                            isLoading = false,
                            errorMessage = response.body()?.message ?: "Failed to fetch console feed"
                        )
                    }
                }
            } catch (e: Exception) {
                _consoleState.update {
                    it.copy(
                        isLoading = false,
                        errorMessage = e.message ?: "Failed to reach console API"
                    )
                }
            }
        }
    }

    private fun extractOtp(text: String): String {
        val dashed = Regex("\\b\\d{3}-\\d{3}\\b").find(text)
        if (dashed != null) return dashed.value
        val digits = Regex("\\b\\d{4,8}\\b").find(text)
        return digits?.value ?: "OTP"
    }
}
